﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using BBCommon;
using UnityEngine.SceneManagement;
//using Heyzap;
using UnityEngine.SocialPlatforms;

public class GameManager : BBCommon.Singleton<GameManager> {


	public static string kAppStoreURL = "https://appstor.es/infinity.path";
	public static string kGooglePlayURL = "https://play.google.com/store/apps/details?id=io.voodoo.paperio&hl=fr";
	public static string kShareText = "OMG!! I have scored {0} in {1}. Can you beat my score? #voodoo";
	public static string kHeyzapId = "8e27867dc132df9524bab1151ce61fc0";//ketchapp: ff4d63e68db9518cacc9a4b5d8e375d8
	public static string kAppStoreId = "1138102771";
	public static string kGooglePlayId = "io.voodoo.paperio";
	public static string kFBAppLink = "fb://page/527358433996753";
	public static string kFBPageLink = "https://www.facebook.com/voodoogames/";
	public static string kLeaderboardName = "com.bbayer.infinitypath";


	public string m_GameState;
	public PlayerCubes player;
	public GameObject selectedPlayer;
	//Events and delegates


	public delegate void OnEventAction(string name, object value);
	public static event OnEventAction OnEvent;

	public Vector3 startPosition;
	public GameObject[] m_Players;
	private PathGenerator pathGen;

	int captureNdx;

	// Use this for initialization
	void Awake(){
		//GameObject ply = Instantiate(m_Players[PlayerPrefs.GetInt("SelectedPlayer",0)]);
		//player = ply.GetComponent<PlayerCubes>();
		InitializeUserPrefs();
		Application.targetFrameRate=60;
		QualitySettings.vSyncCount = 0;
		//Initialize Heyzap
		captureNdx = 0;

	}

	void Start () {	
		Transform[] ts = GetComponentsInChildren<Transform>();
		if (ts.Length > 1) {
			startPosition = ts [1].transform.position;
		}
		MainMenu ();

		//HeyzapAds.ShowDebugLogs();
		// Your Publisher ID is: 8e27867dc132df9524bab1151ce61fc0
		//HeyzapAds.Start(kHeyzapId, HeyzapAds.FLAG_NO_OPTIONS);
		//HZIncentivizedAd.Fetch();
		//HZInterstitialAd.Fetch();
		Social.localUser.Authenticate(OnUserAuthenticate);
		//HZBannerShowOptions opts = new HZBannerShowOptions();
		//opts.Position = HZBannerShowOptions.POSITION_BOTTOM;
		//HZBannerAd.ShowWithOptions(opts);
	}
	
	// Update is called once per frame
	void Update () {
		/*
		if (Input.GetMouseButtonDown (0)) {
			if (m_GameState == GameState.GameStateMainMenu) {
				Input.ResetInputAxes();
				StartGame();
			}
			else if(m_GameState == GameState.GameStateOver){
				Input.ResetInputAxes();
				MainMenu();
			}
		}
		*/

		if(Input.GetKeyDown(KeyCode.P)){
			Application.CaptureScreenshot("capture"+captureNdx+".png");
			captureNdx++;
		}


		if(Input.GetKeyDown(KeyCode.C)){
			ColorManager.Instance.ColorTransition();
		}
		if(Application.targetFrameRate!=60){
			Application.targetFrameRate=60;
		}

		selectedPlayer.transform.position = player.transform.position;
	}

	public void StartGame(){
		////Debug.Log ("Game started");
		m_GameState = "run";
		if (OnEvent != null) {
			OnEvent("gamestate",m_GameState);
		}

	}

	public void FinishGame(){
		////Debug.Log ("Game Over");
		m_GameState = "over";
		if (OnEvent != null) {
			OnEvent("gamestate",m_GameState);
		}

	}

	public void MainMenu(){
		////Debug.Log ("Game main menu");
		/// 
		//if (player) {
		//	Destroy (player.gameObject);
		//}
		//PlayerPrefs.SetInt("SelectedPlayer",0);

		if(selectedPlayer){
			Destroy(selectedPlayer.gameObject);
		}
		selectedPlayer = Instantiate(m_Players[PlayerPrefs.GetInt("SelectedPlayer",0)]);
		//player = ply.GetComponent<PlayerCubes>();
		ColorManager.Instance.ColorTransition ();
		m_GameState = "mainmenu";
		if (OnEvent != null) {
			OnEvent("gamestate",m_GameState);
		}



	}

	public void BestScore(int score){
		if (OnEvent != null) {
			OnEvent("bestscore",score);
		}
	}

	public void ShopMenu(){
		m_GameState = "shopmenu";
		if (OnEvent != null) {
			OnEvent("gamestate",m_GameState);
		}
	}

	public void OnSelectPlayer(){
		ShopMenu();
	}

	void InitializeUserPrefs(){
		//TODO:Remove
		//PlayerPrefs.DeleteAll();

		for (int i=0; i<20; i++) {
			if(!PlayerPrefs.HasKey("IsPlayerUnlocked"+i)){
				PlayerPrefs.SetInt("IsPlayerUnlocked"+i,0);
			}

			if(!PlayerPrefs.HasKey("PlayerBestScore"+i)){
				PlayerPrefs.SetInt("PlayerBestScore"+i,0);
			}

			//TODO:Remove
			//PlayerPrefs.SetInt("IsPlayerUnlocked"+i,1);
		}

		if(!PlayerPrefs.HasKey("BestScore")){
			PlayerPrefs.SetInt("BestScore",0);
		}

		PlayerPrefs.SetInt("IsPlayerUnlocked0",1);

		if(!PlayerPrefs.HasKey("SelectedPlayer")){
			PlayerPrefs.SetInt("SelectedPlayer",0);
		}

		if(!PlayerPrefs.HasKey("TotalCoins")){
			PlayerPrefs.SetInt("TotalCoins",0);
		}

		if(!PlayerPrefs.HasKey("IsAdsRemoved")){
			PlayerPrefs.SetInt("IsAdsRemoved",0);
		}



		//PlayerPrefs.SetInt("TotalCoins",201);

	}

	public void UnlockAll(){
		for (int i=0; i<m_Players.Length; i++) {
			PlayerPrefs.SetInt("IsPlayerUnlocked"+i,1);
		}
	}

	public void LockAll(){
		for (int i=0; i<m_Players.Length; i++) {
			PlayerPrefs.SetInt("IsPlayerUnlocked"+i,0);
		}
		
	}
	//Sharing

	public void OnFacebook(){
		#if UNITY_ANDROID
		if(IsApplication.Installed("com.facebook.katana")){
			Application.OpenURL(kFBAppLink);
		}
		else{
			Application.OpenURL(kFBPageLink);

		}
		#elif UNITY_IOS
		if(IsApplication.Installed(kFBAppLink)){
			Application.OpenURL(kFBAppLink);
		}
		else{
			Application.OpenURL(kFBPageLink);

		}
		#endif
	}

	public void OnRate(){
		#if UNITY_ANDROID
		Application.OpenURL("market://details?id="+kGooglePlayId);
		#elif UNITY_IOS
		Application.OpenURL("itms-apps://itunes.apple.com/app/id"+kAppStoreId);
		#endif	
	}

	public void OnRemoveAds(){
		Debug.Log("onRemoveAds.");
		Purchaser.Instance.BuyNonConsumable ();

	}

	public void OnRestorePurchases(){
		Debug.Log("OnRestorePurchases.");
		Purchaser.Instance.RestorePurchases ();

	}

	public void OnShare(){
		NativeShare ns = new NativeShare ();
		string storeUrl = "http://www.ketchappgames.com";
		#if UNITY_IOS
		storeUrl = kAppStoreURL;
		#elif UNITY_ANDROID
		storeUrl = kGooglePlayURL;
		#endif
		kShareText = string.Format(kShareText,GameManager.Instance.player.m_Score, Application.productName);
		Debug.Log(kShareText);
		try {
			ns.Share (kShareText, Application.persistentDataPath + "/gameover.png", storeUrl, Application.productName);

		} catch (System.Exception ex) {
			
		}
	}

	public void OnLeaderboard(){
		Social.ShowLeaderboardUI ();
	}

	public void OnAchievements(){
		Social.ShowAchievementsUI();

	}

	public void ReportScore(int score){
		try {
			Social.ReportScore(score, kLeaderboardName,null);

		} catch (System.Exception ex) {
			Debug.LogError("cannot report issue")	;
		}
	}

	void OnUserAuthenticate(bool success){
		if(success){
			Debug.Log("User authentication success");
		}
		else{
			Debug.Log("Cannot authenticate user");

		}

	}

	public void OnSuccessfullIAP(string productID){
		PlayerPrefs.SetInt ("IsAdsRemoved", 1);
		//HZBannerAd.Hide ();
	}

	public void OnFailedIAP(string productID, string reason=""){
		Debug.Log ("GameManager: " + productID + " failed with reason:" + reason);
	}

	public void OnHeyzapTestSuit(){
		//HeyzapAds.ShowMediationTestSuite();

	}

	public void PublishEvent(string name , object value){
		if(OnEvent!=null){
			OnEvent(name,value);
		}
	}
}

